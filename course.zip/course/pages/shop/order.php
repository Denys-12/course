<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Отримання даних з POST-запиту
    $name = $_POST['name'];
    $fuelType = $_POST['fuel-type'];
    $fuelQuantity = $_POST['fuel-quantity'];
    $coffeeType = $_POST['coffee-type'];
    $coffeeQuantity = $_POST['coffee-quantity'];


    $fuelPrice;
    if ($fuelType == "Бензин А-95") {
        $fuelPrice = 55.52;
    } else if ($fuelType  == "Бензин А-92") {
        $fuelPrice = 53.65;
    } else if ($fuelType == "Дизельне паливо") {
        $fuelPrice = 55.79;
    } else if ($fuelType  == "Газ автомобільний") {
        $fuelPrice = 29.31;
    }

    $fuelTotal = $fuelPrice * $fuelQuantity;

    $coffeePrice;
            if ($coffeeType == "Лате") {
                $coffeePrice = 48;
            } else if ($coffeeType == "Американо") {
                $coffeePrice = 44;
            } else if ($coffeeType == "Еспресо") {
                $coffeePrice = 38;
            }


    $coffeeTotal = $coffeePrice * $coffeeQuantity;

    // Читання існуючого JSON-файлу (якщо він існує)
    $file = 'замовлення.json';
    $existingData = file_exists($file) ? json_decode(file_get_contents($file), true) : array();

    // Додавання нових даних
    $newData = array(
        'Name' => $name,
        'Fuel' => array(
            'Type' => $fuelType,
            'Quantity' => $fuelQuantity,
            "Total" => $fuelTotal
        ),
        'Coffee' => array(
            'Type' => $coffeeType,
            'Quantity' => $coffeeQuantity,
            "Total" => $coffeeTotal
        ),
        "Total" => $fuelTotal + $coffeeTotal
    );

    

    // Додавання нових даних до існуючих
    $existingData[] = $newData;

    // Кодування даних в формат JSON з кодуванням UTF-8
    $jsonData = json_encode($existingData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

    // Запис JSON-даних у файл з кодуванням UTF-8
    if (file_put_contents($file, $jsonData, LOCK_EX)) {
        echo 'Ваше замовлення прийняте, поверінться в магазин ';
        echo " <a href='./shop.html'>Повернутись назад</a>";
    } else {
        echo 'Ваше замовлення відмовлено ';
    }
}

?>
